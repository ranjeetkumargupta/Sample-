package com.wipro.configuration.service;

import com.wipro.configuration.entity.ConfigVersion;
import com.wipro.configuration.entity.Configuration;

import java.util.List;

public interface ConfigurationService {

    Configuration addConfig(Configuration configuration);

    List<Configuration> getAll();

    Configuration updateConfiguration(Configuration configuration, Long id);

    ConfigVersion findByVersion(String deviceId, int version);

    List<Configuration> getConfigurations(String deviceId);
}
