package com.wipro.configuration.repository;

import com.wipro.configuration.entity.ConfigVersion;
import org.hibernate.cfg.Configuration;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConfigVersionRepository extends JpaRepository<ConfigVersion,Long> {
    ConfigVersion findByDeviceIdAndVersion(String deviceId, int version);
}
