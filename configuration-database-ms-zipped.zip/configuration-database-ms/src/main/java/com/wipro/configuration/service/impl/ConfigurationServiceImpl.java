package com.wipro.configuration.service.impl;

import com.wipro.configuration.entity.ConfigVersion;
import com.wipro.configuration.entity.Configuration;
import com.wipro.configuration.repository.ConfigVersionRepository;
import com.wipro.configuration.repository.ConfigurationRepository;
import com.wipro.configuration.service.ConfigurationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ConfigurationServiceImpl implements ConfigurationService {


    @Autowired
    private ConfigurationRepository configurationRepository;

    @Autowired
    private ConfigVersionRepository configVersionRepository;

    @Override
    public Configuration addConfig(Configuration configuration) {
        final Configuration dataReceivedFromDb = configurationRepository.save(configuration);
        return dataReceivedFromDb;

    }

    @Override
    public List<Configuration> getAll() {
        return configurationRepository.findAll();
    }

    @Override
    public Configuration updateConfiguration(Configuration configuration, Long id) {
        //  finding old configuration using id
        Optional<Configuration> configurationOptional = configurationRepository.findById(id);
        if (configurationOptional.isPresent()) {
            Configuration currentConfiguration = configurationOptional.get();
            //  Storing old configuration into ConfigVersion table
            ConfigVersion configVersion = new ConfigVersion();
            configVersion.setConfiguration(currentConfiguration);
            configVersion.setConfigData(currentConfiguration.getConfigData());
            configVersion.setDeviceId(currentConfiguration.getDeviceId());
            configVersion.setVersion(currentConfiguration.getVersion());
            configVersion.setCreatedAt(currentConfiguration.getCreatedAt());
            configVersionRepository.save(configVersion);

            // storing new configuration coming from controller into configuration table
            Configuration newConfiguration = new Configuration();
            newConfiguration.setId(currentConfiguration.getId());
            newConfiguration.setConfigData(configuration.getConfigData());
            newConfiguration.setVersion(currentConfiguration.getVersion() + 1);
            newConfiguration.setDeviceId(configuration.getDeviceId());
            newConfiguration.setCreatedAt(LocalDateTime.now());
            Configuration savedConfiguration = configurationRepository.save(newConfiguration);
            return savedConfiguration;


        } else {
            throw new RuntimeException("Configuration not found for this id : " + id);
        }
    }

    @Override
    public ConfigVersion findByVersion(String deviceId, int version) {
        ConfigVersion configVersion = configVersionRepository.findByDeviceIdAndVersion(deviceId, version);
        return configVersion;
    }

    @Override
    public List<Configuration> getConfigurations(String deviceId) {
        return configurationRepository.findByDeviceId(deviceId);
    }

}
