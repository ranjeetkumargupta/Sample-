package com.wipro.Database_Microservice;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.wipro.model.Configuration;
import com.wipro.service.ConfigurationService;

@SpringBootTest
public class ConfigurationServiceTest {
	@Autowired
	private ConfigurationService configurationService;

	@Test
	public void testSaveConfiguration() {
		Configuration config = new Configuration();
		config.setDeviceId("device1");
		config.setConfigData("{...}");
		config.setVersion(1);
		Configuration savedConfig = configurationService.saveConfiguration(config);
		assertEquals("device1", savedConfig.getDeviceId());
	}
}