package com.wipro.Database_Microservice;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;

import com.wipro.DatabaseMicroserviceApplication;
import com.wipro.model.Configuration;
import com.wipro.repository.ConfigurationRepository;
import com.wipro.service.ConfigurationServiceImpl;

@DataJpaTest
@SpringBootTest(classes = DatabaseMicroserviceApplication.class)
public class ConfigurationRepositoryTest {

    @Mock
    private ConfigurationRepository configurationRepository;

    @InjectMocks
    private ConfigurationServiceImpl configurationService; // Assuming ConfigurationServiceImpl implements ConfigurationService

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testFindByDeviceId() {
        // Given
        String deviceId = "device-1";
        Configuration config1 = new Configuration(1L, "device-1", "config1", 1, LocalDateTime.now());
        Configuration config2 = new Configuration(2L, "device-1", "config2", 2, LocalDateTime.now());
        List<Configuration> configs = Arrays.asList(config1, config2);

        // Mock the repository method to return the sample configurations
        when(configurationRepository.findByDeviceId(deviceId)).thenReturn(configs);

        // When
        List<Configuration> result = configurationService.getConfigurationsByDeviceId(deviceId);

        // Then
        assertEquals(2, result.size());
        assertEquals("config1", result.get(0).getConfigData());
        assertEquals("config2", result.get(1).getConfigData());
    }
}

