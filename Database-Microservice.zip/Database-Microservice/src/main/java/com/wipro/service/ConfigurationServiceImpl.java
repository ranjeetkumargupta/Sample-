package com.wipro.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.model.ConfigVersion;
import com.wipro.model.Configuration;
import com.wipro.repository.ConfigVersionRepository;
import com.wipro.repository.ConfigurationRepository;

@Service
public class ConfigurationServiceImpl implements ConfigurationService {

    @Autowired
    private ConfigurationRepository configurationRepository;

    @Autowired
    private ConfigVersionRepository configVersionRepository;

    @Transactional
    @Override
    public Configuration saveConfiguration(Configuration configuration) {
        configuration.setCreatedAt(LocalDateTime.now());
        Configuration savedConfig = configurationRepository.save(configuration);

        ConfigVersion configVersion = new ConfigVersion();
        configVersion.setConfiguration(savedConfig);
        configVersion.setDeviceId(savedConfig.getDeviceId());
        configVersion.setConfigData(savedConfig.getConfigData());
        configVersion.setVersion(savedConfig.getVersion());
        configVersion.setCreatedAt(savedConfig.getCreatedAt());
        configVersionRepository.save(configVersion);

        return savedConfig;
    }

    @Override
    public List<Configuration> getConfigurations(String deviceId) {
        return configurationRepository.findByDeviceId(deviceId);
    }

    @Override
    @Transactional
    public Configuration updateConfiguration(Long id, Configuration newConfiguration) {
        Configuration existingConfig = configurationRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Configuration not found for id: " + id));

        existingConfig.setDeviceId(newConfiguration.getDeviceId());
        existingConfig.setConfigData(newConfiguration.getConfigData());
        existingConfig.setVersion(newConfiguration.getVersion());
        return configurationRepository.save(existingConfig);
    }

    @Override
    @Transactional
    public void deleteConfiguration(Long id) {
        Configuration configuration = configurationRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Configuration not found for id: " + id));

        // Delete ConfigVersion by configuration
        configurationRepository.deleteById(id);
        List<ConfigVersion> configVersions = configVersionRepository.findByDeviceId(configuration.getDeviceId());
        configVersionRepository.deleteAll(configVersions);

        // Delete Configuration
        
    }


	@Override
	public List<Configuration> getConfigurationsByDeviceId(String deviceId) {
		 return configurationRepository.findByDeviceId(deviceId);
	}

}
