package com.wipro.service;

import java.util.List;

import com.wipro.model.Configuration;

public interface ConfigurationService {
    Configuration saveConfiguration(Configuration configuration);
    List<Configuration> getConfigurations(String deviceId);
    void deleteConfiguration(Long id);
    List<Configuration> getConfigurationsByDeviceId(String deviceId);
    Configuration updateConfiguration(Long id, Configuration configuration);
}
